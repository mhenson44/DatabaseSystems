<html>
<body>
<?php
include_once 'getEID.php';
$sql = "DELETE FROM employee WHERE EID='" . $_GET["EID"] . "'";
if (mysqli_query($conn, $sql)) {
    echo "Record deleted successfully";
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);

?>
</body>
</html>
